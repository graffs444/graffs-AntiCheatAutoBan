package com.example.anticheatautoban.data;

import org.bukkit.Location;
import java.util.LinkedList;
import java.util.Queue;

public class PlayerData {

    // --- Violation counters ---
    private int flyViolations = 0;
    private int speedViolations = 0;
    private int freecamViolations = 0;
    private int xrayViolations = 0;

    // --- Freecam tracking ---
    private Location lastKnownLocation = null;
    private long lastMoveTime = System.currentTimeMillis();
    private boolean wasStationary = false;

    // --- XRay tracking ---
    private int consecutiveRareOres = 0;
    private final Queue<Long> recentOreMines = new LinkedList<>();

    // ---- Fly ----
    public int getFlyViolations() { return flyViolations; }
    public int incrementFlyViolations() { return ++flyViolations; }
    public void resetFlyViolations() { flyViolations = 0; }
    public void decayFlyViolations() { if (flyViolations > 0) flyViolations--; }

    // ---- Speed ----
    public int getSpeedViolations() { return speedViolations; }
    public int incrementSpeedViolations() { return ++speedViolations; }
    public void resetSpeedViolations() { speedViolations = 0; }
    public void decaySpeedViolations() { if (speedViolations > 0) speedViolations--; }

    // ---- Freecam ----
    public int getFreecamViolations() { return freecamViolations; }
    public int incrementFreecamViolations() { return ++freecamViolations; }
    public void resetFreecamViolations() { freecamViolations = 0; }
    public void decayFreecamViolations() { if (freecamViolations > 0) freecamViolations--; }

    // ---- XRay ----
    public int getXrayViolations() { return xrayViolations; }
    public int incrementXrayViolations() { return ++xrayViolations; }
    public void resetXrayViolations() { xrayViolations = 0; }
    public void decayXrayViolations() { if (xrayViolations > 0) xrayViolations--; }

    // ---- Freecam position tracking ----
    public Location getLastKnownLocation() { return lastKnownLocation; }
    public void setLastKnownLocation(Location loc) { this.lastKnownLocation = loc; }
    public long getLastMoveTime() { return lastMoveTime; }
    public void setLastMoveTime(long t) { this.lastMoveTime = t; }
    public boolean wasStationary() { return wasStationary; }
    public void setWasStationary(boolean b) { this.wasStationary = b; }

    // ---- XRay ore tracking ----
    public int getConsecutiveRareOres() { return consecutiveRareOres; }
    public void incrementConsecutiveRareOres() { consecutiveRareOres++; }
    public void resetConsecutiveRareOres() { consecutiveRareOres = 0; }
    public Queue<Long> getRecentOreMines() { return recentOreMines; }
}
