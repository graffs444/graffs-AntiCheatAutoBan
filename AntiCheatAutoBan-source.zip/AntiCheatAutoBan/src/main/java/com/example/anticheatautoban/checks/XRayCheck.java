package com.example.anticheatautoban.checks;

import com.example.anticheatautoban.AntiCheatAutoBan;
import com.example.anticheatautoban.data.PlayerData;
import com.example.anticheatautoban.discord.DiscordWebhook;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;

import java.util.Queue;
import java.util.Set;

/**
 * XRay detection via behavioral analysis.
 *
 * True XRay cannot be blocked server-side — it runs entirely on the client.
 * This check instead detects the *pattern* XRay produces:
 *   - Players mining many rare ores in quick succession with few non-ore blocks between them.
 *   - Burst mining: hitting the rare-ore-per-30-seconds threshold.
 *
 * XRay NEVER triggers an auto-ban. It only:
 *   - Alerts in-game staff with anticheat.alerts permission
 *   - Logs to Discord for staff review
 *   - Accumulates a violation score
 *
 * Pair with Paper's built-in engine-mode=2 anti-xray (paper-world-defaults.yml)
 * to also make XRay less useful in the first place.
 */
public class XRayCheck {

    private static final Set<Material> RARE_ORES = Set.of(
            Material.DIAMOND_ORE,
            Material.DEEPSLATE_DIAMOND_ORE,
            Material.ANCIENT_DEBRIS,
            Material.EMERALD_ORE,
            Material.DEEPSLATE_EMERALD_ORE,
            Material.GOLD_ORE,
            Material.DEEPSLATE_GOLD_ORE
    );

    private static final long BURST_WINDOW_MS   = 30_000L; // 30 seconds
    private static final int  BURST_THRESHOLD   = 4;       // 4 rare ores in 30s

    private final AntiCheatAutoBan plugin;
    private final DiscordWebhook webhook;

    public XRayCheck(AntiCheatAutoBan plugin, DiscordWebhook webhook) {
        this.plugin = plugin;
        this.webhook = webhook;
    }

    public void onBlockBreak(BlockBreakEvent event, PlayerData data) {
        Player player = event.getPlayer();
        Material broken = event.getBlock().getType();
        Location loc = event.getBlock().getLocation();

        if (loc.getY() > plugin.getXrayMinY()) {
            data.resetConsecutiveRareOres();
            return;
        }

        if (RARE_ORES.contains(broken)) {
            handleRareOre(player, data, broken, loc);
        } else {
            data.resetConsecutiveRareOres();
        }
    }

    private void handleRareOre(Player player, PlayerData data, Material ore, Location loc) {
        long now = System.currentTimeMillis();

        data.incrementConsecutiveRareOres();
        int streak = data.getConsecutiveRareOres();

        Queue<Long> recent = data.getRecentOreMines();
        recent.add(now);
        while (!recent.isEmpty() && (now - recent.peek()) > BURST_WINDOW_MS) {
            recent.poll();
        }
        int burstCount = recent.size();

        boolean suspicious = streak >= plugin.getXraySuspiciousStreak()
                || burstCount >= BURST_THRESHOLD;

        if (suspicious) {
            int violations = data.incrementXrayViolations();
            String detail = String.format(
                    "Mined %s | streak: %d consecutive | %d rare ores in 30s | Y:%.0f | violations: %d",
                    ore.name(), streak, burstCount, loc.getY(), violations
            );

            plugin.getLogger().warning("[AC][XRay] " + player.getName() + " | " + detail);

            webhook.sendAlert(player, "Possible XRay / Ore Finder", detail,
                    DiscordWebhook.Severity.WARNING);

            // Alert online staff in-game
            plugin.getServer().getOnlinePlayers().stream()
                    .filter(p -> p.hasPermission("anticheat.alerts"))
                    .forEach(p -> p.sendMessage(
                            "§c[AntiCheat] §e" + player.getName()
                                    + " §7may be using XRay — check Discord for details."));
        }
    }
}
