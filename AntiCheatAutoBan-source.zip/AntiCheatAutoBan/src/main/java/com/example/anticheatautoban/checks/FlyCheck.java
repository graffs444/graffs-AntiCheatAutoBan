package com.example.anticheatautoban.checks;

import com.example.anticheatautoban.AntiCheatAutoBan;
import com.example.anticheatautoban.data.PlayerData;
import com.example.anticheatautoban.discord.DiscordWebhook;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class FlyCheck {

    private final AntiCheatAutoBan plugin;
    private final DiscordWebhook webhook;

    public FlyCheck(AntiCheatAutoBan plugin, DiscordWebhook webhook) {
        this.plugin = plugin;
        this.webhook = webhook;
    }

    public void check(Player player, PlayerData data) {
        Vector velocity = player.getVelocity();

        if (!player.isOnGround()
                && velocity.getY() > 0.2
                && player.getFallDistance() < 0.5
                && player.getLocation().clone().subtract(0, 0.5, 0).getBlock().isPassable()) {

            int violations = data.incrementFlyViolations();
            String detail = "Upward velocity: " + String.format("%.2f", velocity.getY())
                    + " | violations: " + violations;

            plugin.getLogger().warning("[AC][Fly] " + player.getName() + " | " + detail);

            webhook.sendAlert(player, "Fly Hack Detected", detail,
                    violations >= plugin.getFlyBanThreshold()
                            ? DiscordWebhook.Severity.BAN
                            : DiscordWebhook.Severity.WARNING);

            if (violations >= plugin.getFlyBanThreshold()) {
                plugin.autoBan(player, "Fly hacking (" + violations + " violations)");
            }
        }
    }
}
