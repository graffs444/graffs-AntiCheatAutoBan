package com.example.anticheatautoban;

import com.example.anticheatautoban.checks.FlyCheck;
import com.example.anticheatautoban.checks.FreecamCheck;
import com.example.anticheatautoban.checks.SpeedCheck;
import com.example.anticheatautoban.checks.XRayCheck;
import com.example.anticheatautoban.data.PlayerData;
import com.example.anticheatautoban.discord.DiscordWebhook;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AntiCheatAutoBan extends JavaPlugin implements Listener {

    private final Map<UUID, PlayerData> playerDataMap = new HashMap<>();

    private FlyCheck     flyCheck;
    private SpeedCheck   speedCheck;
    private FreecamCheck freecamCheck;
    private XRayCheck    xrayCheck;
    private DiscordWebhook webhook;

    // Config-loaded thresholds
    private int  flyBanThreshold;
    private int  speedBanThreshold;
    private int  freecamBanThreshold;
    private int  xrayAlertThreshold;
    private int  xrayMinY;
    private int  xraySuspiciousStreak;
    private long decayIntervalTicks;

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfigValues();

        webhook      = new DiscordWebhook(this, getConfig().getString("discord.webhook-url", ""));
        flyCheck     = new FlyCheck(this, webhook);
        speedCheck   = new SpeedCheck(this, webhook);
        freecamCheck = new FreecamCheck(this, webhook);
        xrayCheck    = new XRayCheck(this, webhook);

        getServer().getPluginManager().registerEvents(this, this);

        // Violation decay task — reduces violation counts over time to forgive lag spikes
        Bukkit.getScheduler().runTaskTimer(this, () ->
                playerDataMap.values().forEach(d -> {
                    d.decayFlyViolations();
                    d.decaySpeedViolations();
                    d.decayFreecamViolations();
                    d.decayXrayViolations();
                }),
                decayIntervalTicks, decayIntervalTicks
        );

        getLogger().info("╔══════════════════════════════════════╗");
        getLogger().info("║   AntiCheatAutoBan v1.0.0 enabled    ║");
        getLogger().info("║  Checks: Fly | Speed | Freecam | XRay║");
        getLogger().info("║  Discord webhook: " + (webhookConfigured() ? "✓ configured" : "✗ not set  ") + "    ║");
        getLogger().info("╚══════════════════════════════════════╝");
    }

    @Override
    public void onDisable() {
        getLogger().info("AntiCheatAutoBan disabled.");
    }

    // -------------------------------------------------------------------------
    // Events
    // -------------------------------------------------------------------------

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        playerDataMap.put(event.getPlayer().getUniqueId(), new PlayerData());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        playerDataMap.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (isExempt(player)) return;

        PlayerData data = getOrCreateData(player);

        // Freecam check runs on every event (it also monitors stationary players)
        freecamCheck.check(player, data, event.getFrom(), event.getTo());

        // Other checks only fire when block position actually changes (not just head rotation)
        if (!hasChangedBlockPosition(event)) return;

        flyCheck.check(player, data);
        speedCheck.check(player, data, event.getFrom(), event.getTo());
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (player.getGameMode() == GameMode.CREATIVE) return;

        PlayerData data = getOrCreateData(player);
        xrayCheck.onBlockBreak(event, data);
    }

    // -------------------------------------------------------------------------
    // Public API (used by check classes)
    // -------------------------------------------------------------------------

    public void autoBan(Player player, String reason) {
        UUID id = player.getUniqueId();
        PlayerData data = playerDataMap.get(id);
        if (data != null) {
            data.resetFlyViolations();
            data.resetSpeedViolations();
            data.resetFreecamViolations();
        }

        webhook.sendAlert(player, "⛔ PLAYER BANNED", reason, DiscordWebhook.Severity.BAN);

        String name = player.getName();
        getLogger().warning("[AC] Banning " + name + " for: " + reason);
        Bukkit.getScheduler().runTask(this, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + name + " " + reason)
        );
    }

    // Threshold getters
    public int getFlyBanThreshold()       { return flyBanThreshold; }
    public int getSpeedBanThreshold()     { return speedBanThreshold; }
    public int getFreecamBanThreshold()   { return freecamBanThreshold; }
    public int getXrayAlertThreshold()    { return xrayAlertThreshold; }
    public int getXrayMinY()              { return xrayMinY; }
    public int getXraySuspiciousStreak()  { return xraySuspiciousStreak; }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private boolean isExempt(Player player) {
        GameMode gm = player.getGameMode();
        return gm == GameMode.CREATIVE
                || gm == GameMode.SPECTATOR
                || player.isFlying()
                || player.isInsideVehicle()
                || player.hasPermission("anticheat.bypass")
                || player.isGliding()
                || player.hasPotionEffect(PotionEffectType.JUMP)
                || player.hasPotionEffect(PotionEffectType.LEVITATION)
                || player.hasPotionEffect(PotionEffectType.SLOW_FALLING);
    }

    private boolean hasChangedBlockPosition(PlayerMoveEvent event) {
        return event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockY() != event.getTo().getBlockY()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ();
    }

    private PlayerData getOrCreateData(Player player) {
        return playerDataMap.computeIfAbsent(player.getUniqueId(), k -> new PlayerData());
    }

    private void loadConfigValues() {
        flyBanThreshold      = getConfig().getInt("thresholds.fly-ban", 10);
        speedBanThreshold    = getConfig().getInt("thresholds.speed-ban", 8);
        freecamBanThreshold  = getConfig().getInt("thresholds.freecam-ban", 6);
        xrayAlertThreshold   = getConfig().getInt("thresholds.xray-alert", 5);
        xrayMinY             = getConfig().getInt("xray.min-y-level", 20);
        xraySuspiciousStreak = getConfig().getInt("xray.suspicious-ore-streak", 5);
        decayIntervalTicks   = getConfig().getLong("decay-interval-ticks", 100L);
    }

    private boolean webhookConfigured() {
        String url = getConfig().getString("discord.webhook-url", "");
        return url != null && !url.contains("YOUR_WEBHOOK");
    }
}
