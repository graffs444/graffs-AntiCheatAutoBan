package com.example.anticheatautoban.discord;

import com.example.anticheatautoban.AntiCheatAutoBan;
import org.bukkit.entity.Player;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;

public class DiscordWebhook {

    private final AntiCheatAutoBan plugin;
    private final String webhookUrl;

    public enum Severity {
        INFO(3447003),       // Blue
        WARNING(16776960),   // Yellow
        BAN(16711680);       // Red

        public final int color;
        Severity(int color) { this.color = color; }
    }

    public DiscordWebhook(AntiCheatAutoBan plugin, String webhookUrl) {
        this.plugin = plugin;
        this.webhookUrl = webhookUrl;
    }

    /**
     * Sends a rich embed alert to Discord. Runs asynchronously — safe to call from any thread.
     */
    public void sendAlert(Player player, String checkName, String detail, Severity severity) {
        if (!plugin.getConfig().getBoolean("discord.enabled", true)) return;
        if (webhookUrl == null || webhookUrl.contains("YOUR_WEBHOOK")) {
            plugin.getLogger().warning("[Discord] Webhook URL not configured in config.yml!");
            return;
        }

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                String location = String.format("X:%.1f Y:%.1f Z:%.1f in %s",
                        player.getLocation().getX(),
                        player.getLocation().getY(),
                        player.getLocation().getZ(),
                        player.getWorld().getName());

                String icon = switch (severity) {
                    case BAN     -> "🔨";
                    case WARNING -> "⚠️";
                    default      -> "ℹ️";
                };

                String json = "{"
                        + "\"embeds\": [{"
                        + "\"title\": \"" + icon + " " + escapeJson(checkName) + "\","
                        + "\"color\": " + severity.color + ","
                        + "\"fields\": ["
                        + "{\"name\":\"Player\",\"value\":\"" + escapeJson(player.getName()) + "\",\"inline\":true},"
                        + "{\"name\":\"UUID\",\"value\":\"" + player.getUniqueId() + "\",\"inline\":true},"
                        + "{\"name\":\"Ping\",\"value\":\"" + player.getPing() + "ms\",\"inline\":true},"
                        + "{\"name\":\"Detail\",\"value\":\"" + escapeJson(detail) + "\",\"inline\":false},"
                        + "{\"name\":\"Location\",\"value\":\"" + escapeJson(location) + "\",\"inline\":false}"
                        + "],"
                        + "\"footer\":{\"text\":\"AntiCheatAutoBan v1.0.0\"},"
                        + "\"timestamp\":\"" + Instant.now() + "\""
                        + "}]}";

                URL url = new URL(webhookUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                if (code != 204) {
                    plugin.getLogger().warning("[Discord] Webhook returned HTTP " + code);
                }
                conn.disconnect();

            } catch (Exception e) {
                plugin.getLogger().warning("[Discord] Failed to send alert: " + e.getMessage());
            }
        });
    }

    private String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}
