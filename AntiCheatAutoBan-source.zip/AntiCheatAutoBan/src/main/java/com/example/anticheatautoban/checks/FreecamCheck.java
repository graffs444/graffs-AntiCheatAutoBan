package com.example.anticheatautoban.checks;

import com.example.anticheatautoban.AntiCheatAutoBan;
import com.example.anticheatautoban.data.PlayerData;
import com.example.anticheatautoban.discord.DiscordWebhook;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * Freecam detection detects two patterns:
 *
 * 1. POSITION SNAP: After being stationary for 8+ seconds, the player
 *    suddenly teleports 5+ blocks in one tick. Freecam users "snap" back
 *    to their real body position when they close the module.
 *
 * 2. PITCH LOCK: Player's camera pitch is locked at extreme vertical angles
 *    (near ±90°) while their body hasn't moved — a pattern of certain
 *    freecam implementations that lock the camera perspective.
 */
public class FreecamCheck {

    private static final long STATIONARY_THRESHOLD_MS = 8000; // 8 seconds
    private static final double SNAP_DISTANCE = 5.0;           // blocks
    private static final float PITCH_LOCK_THRESHOLD = 89.5f;

    private final AntiCheatAutoBan plugin;
    private final DiscordWebhook webhook;

    public FreecamCheck(AntiCheatAutoBan plugin, DiscordWebhook webhook) {
        this.plugin = plugin;
        this.webhook = webhook;
    }

    public void check(Player player, PlayerData data, Location from, Location to) {
        long now = System.currentTimeMillis();
        boolean positionChanged = hasPositionChanged(from, to);

        if (positionChanged) {
            if (data.wasStationary() && data.getLastKnownLocation() != null) {
                double snapDistance = data.getLastKnownLocation().distance(to);
                if (snapDistance > SNAP_DISTANCE) {
                    flag(player, data,
                            "Position snap after stationary period ("
                                    + String.format("%.1f", snapDistance) + " blocks)");
                }
            }
            data.setLastKnownLocation(to.clone());
            data.setLastMoveTime(now);
            data.setWasStationary(false);

        } else {
            long stationaryMs = now - data.getLastMoveTime();
            if (stationaryMs > STATIONARY_THRESHOLD_MS) {
                data.setWasStationary(true);
                float pitch = player.getLocation().getPitch();
                if (Math.abs(pitch) >= PITCH_LOCK_THRESHOLD) {
                    flag(player, data,
                            "Pitch locked at " + String.format("%.1f", pitch)
                                    + "° while stationary for " + (stationaryMs / 1000) + "s");
                }
            }
        }
    }

    private void flag(Player player, PlayerData data, String detail) {
        int violations = data.incrementFreecamViolations();
        plugin.getLogger().warning("[AC][Freecam] " + player.getName()
                + " | " + detail + " | violations: " + violations);

        webhook.sendAlert(player, "Freecam Detected", detail + " | violations: " + violations,
                violations >= plugin.getFreecamBanThreshold()
                        ? DiscordWebhook.Severity.BAN
                        : DiscordWebhook.Severity.WARNING);

        if (violations >= plugin.getFreecamBanThreshold()) {
            plugin.autoBan(player, "Freecam (" + violations + " violations)");
        }
    }

    private boolean hasPositionChanged(Location from, Location to) {
        return from.getBlockX() != to.getBlockX()
                || from.getBlockY() != to.getBlockY()
                || from.getBlockZ() != to.getBlockZ();
    }
}
