package com.example.anticheatautoban.checks;

import com.example.anticheatautoban.AntiCheatAutoBan;
import com.example.anticheatautoban.data.PlayerData;
import com.example.anticheatautoban.discord.DiscordWebhook;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class SpeedCheck {

    private static final double SPEED_THRESHOLD = 1.5;

    private final AntiCheatAutoBan plugin;
    private final DiscordWebhook webhook;

    public SpeedCheck(AntiCheatAutoBan plugin, DiscordWebhook webhook) {
        this.plugin = plugin;
        this.webhook = webhook;
    }

    public void check(Player player, PlayerData data, Location from, Location to) {
        double horizontal = Math.sqrt(
                Math.pow(to.getX() - from.getX(), 2)
                        + Math.pow(to.getZ() - from.getZ(), 2)
        );

        if (horizontal > SPEED_THRESHOLD) {
            int violations = data.incrementSpeedViolations();
            String detail = "Moved " + String.format("%.2f", horizontal)
                    + " blocks horizontally | violations: " + violations;

            plugin.getLogger().warning("[AC][Speed] " + player.getName() + " | " + detail);

            webhook.sendAlert(player, "Speed Hack Detected", detail,
                    violations >= plugin.getSpeedBanThreshold()
                            ? DiscordWebhook.Severity.BAN
                            : DiscordWebhook.Severity.WARNING);

            if (violations >= plugin.getSpeedBanThreshold()) {
                plugin.autoBan(player, "Speed hacking (" + violations + " violations)");
            }
        }
    }
}
