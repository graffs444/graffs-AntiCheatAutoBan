# AntiCheatAutoBan

A Spigot/Paper Minecraft plugin with fly, speed, freecam, and XRay detection — plus Discord webhook alerting.

## Checks

| Check    | What it detects                                          | Auto-ban? |
|----------|----------------------------------------------------------|-----------|
| Fly      | Sustained upward velocity without ground contact         | ✅ Yes     |
| Speed    | Horizontal movement exceeding sprint maximum             | ✅ Yes     |
| Freecam  | Position snapping after stationary period, pitch lock    | ✅ Yes     |
| XRay     | Ore streak & burst mining patterns below Y=20            | ❌ Alert only |
| Discord  | All of the above, with location/UUID/ping embed          | Always    |

---

## Requirements

- Java 17+
- Maven 3.6+
- Spigot or Paper 1.20.x

---

## Building the JAR

```bash
# 1. Clone or extract the project folder
cd AntiCheatAutoBan

# 2. Build with Maven
mvn clean package

# 3. The compiled JAR will be at:
#    target/AntiCheatAutoBan-1.0.0.jar
```

---

## Installation

1. Copy `target/AntiCheatAutoBan-1.0.0.jar` into your server's `plugins/` folder.
2. Start your server once to generate `plugins/AntiCheatAutoBan/config.yml`.
3. Open `config.yml` and paste in your Discord webhook URL.
4. Run `/reload confirm` or restart the server.

---

## Discord Webhook Setup

1. In your Discord server, go to a channel → **Edit Channel** → **Integrations** → **Webhooks**.
2. Click **New Webhook**, give it a name, and copy the URL.
3. Paste the URL into `config.yml`:

```yaml
discord:
  webhook-url: "https://discord.com/api/webhooks/123456789/abcdefg..."
  enabled: true
```

---

## Configuration (`config.yml`)

```yaml
discord:
  webhook-url: "https://discord.com/api/webhooks/YOUR_WEBHOOK_ID/YOUR_WEBHOOK_TOKEN"
  enabled: true

thresholds:
  fly-ban: 10       # violations before ban
  speed-ban: 8
  freecam-ban: 6
  xray-alert: 5     # XRay never auto-bans

xray:
  min-y-level: 20              # only check mining below this Y
  suspicious-ore-streak: 5     # consecutive rare ores before flagging

decay-interval-ticks: 100      # how often violations decrease (20 ticks = 1 second)
```

---

## Permissions

| Permission          | Description                        | Default |
|---------------------|------------------------------------|---------|
| `anticheat.bypass`  | Bypasses all checks                | OP      |
| `anticheat.alerts`  | Receives in-game XRay alerts       | OP      |

---

## Notes

- **XRay** is alert-only by design. Client-side XRay cannot be technically blocked server-side. Pair this plugin with Paper's built-in `engine-mode: 2` anti-xray in `paper-world-defaults.yml` for best results.
- **Freecam** detection uses position-snap and pitch-lock heuristics. AFK players with extreme camera angles may occasionally trigger it — tune the `freecam-ban` threshold higher if needed.
- **Violation decay** means a lag spike won't instantly ban a legitimate player. Violations decrease over time.
